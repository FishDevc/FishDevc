local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP")

src = {}
Tunnel.bindInterface("fsh_ffa", src)

vCLIENT = Tunnel.getInterface("fsh_ffa")

local ArenasFFA = {
    [1] = {},
}


function src.CheckParticipantes(IDArena)

    local source = source

    local user_id = vRP.getUserId(source)

    if #ArenasFFA[IDArena] < 5 then

        table.insert(ArenasFFA[IDArena], {user_id = user_id, source = source})

        TriggerClientEvent('Notify', source, 'sucesso', 'SUCESSO ARENA FFA!', 'Você entro