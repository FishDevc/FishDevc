local Tunnel = module("vrp","lib/Tunnel")
local Proxy = module("vrp","lib/Proxy")
vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP")

vSERVER = Tunnel.getInterface("fall")

src = {}
Tunnel.bindInterface("fall", src)


local Arena = 0

local ParticipatingArena = false

local FFA = {

    [1] = {

        centrao = {['x'] = -1740.87, ['y'] = 157.98, ['z'] = 64.38, ['h'] = 259.16},

        entrada = {['x'] = -1810.25, ['y'] = -1207.98, ['z'] = 14.31, ['h'] = 221.76},

        spawns = {

            [1] = {['x'] = -1770.11, ['y'] = 175.73, ['z'] = 64.38, ['h'] = 124.45},

            [2] = {['x'] = -1759.71, ['y'] = 190.03, ['z'] = 64.38, ['h'] = 294.83},

            [3] = {['x'] = -1741.59, ['y'] = 190.54, ['z'] = 64.38, ['h'] = 117.92},

            [4] = {['x'] = -1755.68, ['y'] = 185.6, ['z'] = 64.44, ['h'] = 216.59},

            [5] = {['x'] = -1736.9, ['y'] = 188.91, ['z'] = 64.38, ['h'] = 180.86},

            [6] = {['x'] = -1727.88, ['y'] = 182.39, ['z'] = 64.36, ['h'] = 118.9},

            [7] = {['x'] = -1745.26, ['y'] = 172.91, ['z'] = 64.38, ['h'] = 222.32},

            [8] = {['x'] = -1756.59, ['y'] = 172.91, ['z'] = 64.38, ['h'] = 255.94},

            [9] = {['x'] = -1766.86, ['y'] = 169.85, ['z'] = 64.38, ['h'] = 217.99},

            [10] = {['x'] = -1748.68, ['y'] = 157.9, ['z'] = 64.38, ['h'] = 84.8    },

            [11] = {['x'] = -1760.7, ['y'] = 143.52, ['z'] = 64.38, ['h'] = 289.55},

            [12] = {['x'] = -1743.56, ['y'] = 128.21, ['z'] = 64.38, ['h'] = 331.23},

            [13] = {['x'] = -1732.74, ['y'] = 140.51, ['z'] = 64.38, ['h'] = 99.19},

            [14] = {['x'] = -1730.81, ['y'] = 141.08, ['z'] = 64.38, ['h'] = 202.64},

            [15] = {['x'] = -1716.63, ['y'] = 138.59, ['z'] = 64.38, ['h'] = 35.53  },

            [16] = {['x'] = -1716.29, ['y'] = 162.18, ['z'] = 64.38, ['h'] = 299.62},

            [17] = {['x'] = -1725.25, ['y'] = 167.47, ['z'] = 64.38, ['h'] = 61.84},

            [18] = {['x'] = -1725.1, ['y'] = 169.14, ['z'] = 64.38, ['h'] = 193.1},

            [19] = {['x'] = -1726.95, ['y'] = 169.38, ['z'] = 64.38, ['h'] = 195.76},

            [20] = {['x'] = -1727.0, ['y'] = 167.09, ['z'] = 64.38, ['h'] = 270.31},

            [21] = {['x'] = -1724.09, ['y'] = 143.5, ['z'] = 64.38, ['h'] = 60.47},

            [22] = {['x'] = -1746.66, ['y'] = 148.79, ['z'] = 64.37, ['h'] = 118.48},

            [23] = {['x'] = -1762.8, ['y'] = 153.15, ['z'] = 64.38, ['h'] = 77.61},

            [24] = {['x'] = -1768.45, ['y'] = 172.02, ['z'] = 64.38, ['h'] = 348.19},

            [25] = {['x'] = -1767.84, ['y'] = 180.68, ['z'] = 64.38, ['h'] = 164.23},

            [26] = {['x'] = -1746.63, ['y'] = 147.92, ['z'] = 64.37, ['h'] = 308.69},

            [27] = {['x'] = -1736.84, ['y'] = 138.52, ['z'] = 64.38, ['h'] = 248.84},

            [28] = {['x'] = -1734.86, ['y'] = 124.13, ['z'] = 64.38, ['h'] = 141.0},

            [29] = {['x'] = -1719.79, ['y'] = 136.52, ['z'] = 64.38, ['h'] = 314.57},

            [30] = {['x'] = -1734.11, ['y'] = 151.9, ['z'] = 64.38, ['h'] = 122.08},

            [31] = {['x'] = -1746.99, ['y'] = 165.8, ['z'] = 64.38, ['h'] = 82.42},

            [32] = {['x'] = -1743.61, ['y'] = 171.85, ['z'] = 67.22, ['h'] = 227.1},

            [33] = {['x'] = -1758.76, ['y'] = 190.05, ['z'] = 64.38, ['h'] = 221.13},

            [34] = {['x'] = -1758.92, ['y'] = 180.79, ['z'] = 64.38, ['h'] = 240.26},

            [35] = {['x'] = -1758.63, ['y'] = 175.36, ['z'] = 64.38, ['h'] = 173.82},

            [36] = {['x'] = -1751.41, ['y'] = 164.64, ['z'] = 64.38, ['h'] = 243.25},

            [37] = {['x'] = -1743.42, ['y'] = 160.57, ['z'] = 64.38, ['h'] = 243.03},

            [38] = {['x'] = -1735.74, ['y'] = 163.04, ['z'] = 64.38, ['h'] = 286.58},

            [39] = {['x'] = -1732.8, ['y'] = 172.23, ['z'] = 64.38, ['h'] = 347.99},

            [40] = {['x'] = -1726.7, ['y'] = 176.54, ['z'] = 64.38, ['h'] = 310.78},

            [41] = {['x'] = -1723.78, ['y'] = 169.93, ['z'] = 64.38, ['h'] = 190.6},

            [42] = {['x'] = -1727.02, ['y'] = 160.49, ['z'] = 64.38, ['h'] = 141.32},

            [43] = {['x'] = -1730.9, ['y'] = 146.18, ['z'] = 64.38, ['h'] = 167.45},

            [44] = {['x'] = -1739.79, ['y'] = 149.6, ['z'] = 64.38, ['h'] = 84.52},

            [45] = {['x'] = -1746.49, ['y'] = 146.25, ['z'] = 64.37, ['h'] = 150.91},

            [46] = {['x'] = -1742.95, ['y'] = 133.59, ['z'] = 64.38, ['h'] = 246.26},

            [47] = {['x'] = -1720.21, ['y'] = 147.75, ['z'] = 64.38, ['h'] = 316.88},

            [48] = {['x'] = -1712.3, ['y'] = 150.17, ['z'] = 64.38, ['h'] = 253.08},

            [49] = {['x'] = -1740.24, ['y'] = 173.87, ['z'] = 64.38, ['h'] = 68.09},

            [50] = {['x'] = -1743.63, ['y'] = 179.24, ['z'] = 64.38, ['h'] = 79.64},

            [51] = {['x'] = -1731.36, ['y'] = 182.25, ['z'] = 64.38, ['h'] = 282.13},

            [52] = {['x'] = -1738.63, ['y'] = 187.08, ['z'] = 64.38, ['h'] = 53.36}

        }
    }
}





Citizen.CreateThread(function() 

    while true do

        Wait(0)

        local ped = PlayerPedId()

        local pedCoords = GetEntityCoords(ped)



        
        if not ParticipatingArena then

            for k , v in pairs(FFA) do

                local dist = Vdist(pedCoords, v.entrada.x, v.entrada.y, v.entrada.z)


                if dist < 15 then

                    DrawMarker(4, v.entrada.x, v.entrada.y, v.entrada.z, 0, 0, 0, 180.0, 0, 0, 0.5, 0.5, 0.5, 237, 209, 111,150, 0, 0, 0, 1)

                    if dist < 1.5 then

                        text3D(v.entrada.x, v.entrada.y, v.entrada.z,'~y~[H] ~w~PARA ENTRAR NA ~y~ARENA FREE-FOR-ALL (MÁX. 5) ~w~- LOBBY: ~w~'..k)

                        if IsControlJustPressed(0,74) then

                            if vSERVER.CheckParticipantes(k) then

                                TriggerEvent('fsh:Morte:ApertarE', false)

                                ParticipatingArena = true

                                Arena = k

                                SetEntityHealth(ped, 399)

                                local spawn = math.random(#v.spawns)

                                SetEntityCoords(ped, v.spawns[spawn].x, v.spawns[spawn].y, v.spawns[spawn].z-0.96)

                            end

                        end

                    end

                end


                local dist2 = Vdist(pedCoords,v.centrao.x, v.centrao.y, v.centrao.z)

                if dist2 <= 76 then

                    TriggerEvent('fsh:RenascerEmOutroLugar')

                    TriggerEvent('Notify', 'aviso', 'AVISO ARENA FFA!', 'Você não está participando dessa arena, sai fora!')

                end

            end



        else
            local dist = Vdist(pedCoords,  FFA[Arena].centrao.x, FFA[Arena].centrao.y, FFA[Arena].centrao.z)

            local vida = GetEntityHealth(ped)



            if dist > 76 then

                SetEntityCoords(ped, FFA[Arena].centrao.x, FFA[Arena].centrao.y, FFA[Arena].centrao.z-0.96)

            end
            

            if vida <= 101 then

                local spawn = math.random(#FFA[Arena].spawns)
                
                local a,b,c = table.unpack(GetEntityCoords(ped))

                TriggerServerEvent('fsh:PontosRenascer',a,b,c,true)

                Wait(2000)

                vRP.killGod()

                SetEntityHealth(ped, 399)

                SetEntityCoords(ped, FFA[Arena].spawns[spawn].x, FFA[Arena].spawns[spawn].y, FFA[Arena].spawns[spawn].z-0.96)

            end



            if IsControlJustPressed(0,168) then

                TriggerEvent('fsh:Morte:ApertarE', true)

                SetEntityCoords(ped, FFA[Arena].entrada.x, FFA[Arena].entrada.y, FFA[Arena].entrada.z-0.96)

                vSERVER.GetOutArena(Arena)

                Arena = 0

                ParticipatingArena = false
                
            end



            if GetSelectedPedWeapon(ped) ~= GetHashKey('WEAPON_SNSPISTOL') 

            and GetSelectedPedWeapon(ped) ~= GetHashKey('WEAPON_COMBATPISTOL') 

            and GetSelectedPedWeapon(ped) ~= GetHashKey('WEAPON_HEAVYPISTOL') 

            and GetSelectedPedWeapon(ped) ~= GetHashKey('WEAPON_PISTOL_MK2')

            then

                SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)

            end

        end

    end

end)





-- TEXT3D
function text3D(x,y,z,text)

	local onScreen,_x,_y = World3dToScreen2d(x,y,z)

	SetTextFont(1)

	SetTextScale(0.35,0.35)

	SetTextColour(255,255,255,150)

	SetTextEntry("STRING")

	SetTextCentre(1)

	AddTextComponentString(text)

	DrawText(_x,_y)

	local factor = (string.len(text))/300

	DrawRect(_x,_y+0.0125,0.01+factor,0.03,0,0,0,80)

end
